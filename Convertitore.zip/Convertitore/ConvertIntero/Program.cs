﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertIntero
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool[] BOOL = new bool[32];
            int[] DecimalePuntato = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32};
            for (int i = 0; i < BOOL.Length; i++)
            {
                BOOL[i] = Convert.ToBoolean(Console.ReadLine());
            }
            Console.WriteLine("Conversione: " + Convert_Binario_To_Decimale(BOOL));
            Console.WriteLine("Conversione: " + Convert_Decimale_Puntato_To_Decimale(DecimalePuntato));
            Console.ReadLine();
        }
        static int Convert_Binario_To_Decimale(bool[] BOOL)
        {
            int BinarioDecimale = 0;
            int esponente = 0;
            for (int i = BOOL.Length - 1; i >= 0; i--)
            {
                if (BOOL[i] == true)
                {
                    BinarioDecimale += (int)Math.Pow(2, esponente);
                }
                esponente++;
            }
            return BinarioDecimale;
        }
        static int Convert_Decimale_Puntato_To_Decimale(int[] DecimalePuntato)
        {
            int DecimalePuntatoDec = 0;
            int potenza = 0;
            for (int i = DecimalePuntato.Length - 1; i >= 0; i--)
            {
                DecimalePuntatoDec += DecimalePuntato[i] * (int)Math.Pow(256, potenza);
                potenza++;
            }
            return DecimalePuntatoDec;
        }
    }
}
